// payment.js

// Replace with your own Stripe public key
const stripe = Stripe('your-publishable-key');
const elements = stripe.elements();

// Set up Stripe.js and Elements to use in checkout form
const card = elements.create('card');
card.mount('#card-element');

// Handle form submission
const form = document.getElementById('payment-form');
const submitButton = document.getElementById('submit');
const paymentStatus = document.getElementById('payment-status');
const cardErrors = document.getElementById('card-errors');

form.addEventListener('submit', async (event) => {
    event.preventDefault();

    // Disable the submit button to prevent multiple clicks
    submitButton.disabled = true;

    const {token, error} = await stripe.createToken(card);

    if (error) {
        // Show error message
        cardErrors.textContent = error.message;
        submitButton.disabled = false;
    } else {
        // Send token to your server
        const response = await fetch('/charge', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ token: token.id }),
            
        });

        const result = await response.json();

        if (result.error) {
            cardErrors.textContent = result.error.message;
        } else {
            // If payment is successful, show a success message
            paymentStatus.classList.remove('hidden');
            form.classList.add('hidden');
        }
    }
});
