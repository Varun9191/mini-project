document.addEventListener("DOMContentLoaded", () => {
  const busData = {
    "49M": {
      route: ["Mehdipatnam", "Lakdikapul", "Nampally", "Secunderabad"],
      hotels: [
        { name: "Santosh Dhaba", menu: ["Veg Biryani", "Paneer Butter Masala", "Aloo Gobi"] },
        { name: "Mehfil", menu: ["Chicken Biryani", "Mutton Curry", "Fish Fry"] },
        { name: "KFC", menu: ["Pasta", "Pizza", "Sandwich"] }
      ],
      schedule: {
        "Mehdipatnam": "08:00",
        "Lakdikapul": "08:10",
        "Nampally": "08:20",
        "Secunderabad": "08:30"
      }
    },
    "19F": {
      route: ["Mehdipatnam", "Ameerpet", "Erragadda", "Borabanda"],
      hotels: [
        { name: "Santosh Dhaba", menu: ["Veg Biryani", "Paneer Butter Masala", "Aloo Gobi"] },
        { name: "Mehfil", menu: ["Chicken Biryani", "Mutton Curry", "Fish Fry"] },
        { name: "KFC", menu: ["Pasta", "Pizza", "Sandwich"] }
      ],
      schedule: {
        "Mehdipatnam": "08:00",
        "Ameerpet": "08:10",
        "Erragadda": "08:20",
        "Borabanda": "08:30"
      }
    },
    "505": {
      route: ["Mehdipatnam", "Gachibowli", "Kokapet", "Shankarpalli"],
      hotels: [
        { name: "Santosh Dhaba", menu: ["Veg Biryani", "Paneer Butter Masala", "Aloo Gobi"] },
        { name: "Mehfil", menu: ["Chicken Biryani", "Mutton Curry", "Fish Fry"] },
        { name: "KFC", menu: ["Pasta", "Pizza", "Sandwich"] }
      ],
      schedule: {
        "Mehdipatnam": "08:00",
        "Gachibowli": "08:15",
        "Kokapet": "08:25",
        "Shankarpalli": "08:35"
      }
    }
  };

  // Global orders array
  let orders = [];

  // Attach event listeners to navigation buttons
  document.getElementById("placeOrderBtn").addEventListener("click", showOrderForm);
  document.getElementById("startDeliveryBtn").addEventListener("click", showDeliveryForm);
  document.getElementById("exitBtn").addEventListener("click", exit);
  document.getElementById("backToMenuBtn").addEventListener("click", backToMenu);
  document.getElementById("backToMenuBtn2").addEventListener("click", backToMenu);
  document.getElementById("submitOrderBtn").addEventListener("click", placeOrder);
  document.getElementById("startDeliveryBtnSubmit").addEventListener("click", startDelivery);

  function showOrderForm() {
    document.getElementById("orderForm").style.display = "block";
    document.getElementById("deliveryForm").style.display = "none";
  }

  function showDeliveryForm() {
    document.getElementById("deliveryForm").style.display = "block";
    document.getElementById("orderForm").style.display = "none";
  }

  function backToMenu() {
    document.getElementById("orderForm").style.display = "none";
    document.getElementById("deliveryForm").style.display = "none";
  }

  function placeOrder() {
    const customerName = document.getElementById("customerName").value;
    const busNo = document.getElementById("busNo").value;
    const mealChoice = document.getElementById("mealChoice").value;
    const deliveryStop = document.getElementById("deliveryStop").value;
    const deliveryTime = document.getElementById("deliveryTime").value;

    // Validation for empty fields
    if (!customerName || !mealChoice || !deliveryStop || !deliveryTime) {
      alert("Please fill all fields");
      return;
    }

    // Get selected bus data
    const bus = busData[busNo];
    if (!bus) {
      alert("Invalid bus number");
      return;
    }

    // Validate meal choice
    const allMeals = bus.hotels.flatMap(hotel => hotel.menu);
    if (!allMeals.includes(mealChoice)) {
      alert("Invalid meal choice");
      return;
    }

    // Validate delivery stop
    if (!bus.route.includes(deliveryStop)) {
      alert("Invalid delivery stop");
      return;
    }

    // Add the order
    const order = { customerName, mealChoice, deliveryStop, deliveryTime, busNo };
    orders.push(order);
    //alert(`Order placed successfully for ${customerName}`);
    window.open("payment.html", "_blank"); // Redirect to payment
    backToMenu();
  }

  function startDelivery() {
    const busNo = document.getElementById("deliveryBusNo").value;
    const bus = busData[busNo];

    if (!bus) {
      alert("Invalid bus number");
      return;
    }

    const route = bus.route;
    let deliveryMessage = "Starting delivery...\n";

    orders.forEach(order => {
      if (order.busNo === busNo) {
        deliveryMessage += `Delivering ${order.mealChoice} to ${order.customerName} at ${order.deliveryStop}\n`;
      }
    });

    document.getElementById("message").textContent = deliveryMessage || "No deliveries scheduled for this bus.";
    backToMenu();
  }

  function exit() {
    alert("Exiting program...");
    window.close();
  }
});
