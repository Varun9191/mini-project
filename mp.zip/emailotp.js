// Validate email function
function validateEmail(email) {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
}

// Function to send OTP
function sendOTP() {
    const email = document.getElementById('email'); // Get email input
    const otpverify = document.getElementsByClassName('otpverify')[0]; // Get OTP section

    // Validate email
    if (!validateEmail(email.value)) {
        alert("Please enter a valid email address.");
        email.focus(); // Focus on the email field for better UX
        return;
    }

    let otp_val = Math.floor(1000 + Math.random() * 9000); // Generate a 4-digit OTP
    console.log("Generated OTP:", otp_val); // Debugging: Log OTP to the console

    let emailbody = `<h2>Your OTP is:</h2><p>${otp_val}</p>`; // Email body

    // Send email using SMTP.js
    Email.send({
        SecureToken: "d15d099c-e6a0-49a9-b40a-3e360d6cbd47",
        To: email.value,
        From: "p.sainavaneeth5889@gmail.com",
        Subject: "OTP Verification",
        Body: emailbody,
    })
        .then((message) => {
            if (message === "OK") {
                alert(`OTP sent successfully to ${email.value}`);
                otpverify.style.display = "flex"; // Show OTP input section

                const otp_inp = document.getElementById('otp_inp'); // OTP input field
                const otp_btn = document.getElementById('otp_btn'); // OTP verification button

                // Remove existing event listener if any
                otp_btn.onclick = null;

                // Attach a single event listener for OTP verification
                otp_btn.onclick = () => {
                    const userInput = otp_inp.value.trim();

                    // Validate OTP input
                    if (!userInput) {
                        alert("Please enter the OTP.");
                        otp_inp.focus();
                        return;
                    }

                    if (userInput == otp_val) {
                        alert("OTP verified successfully!");
                        window.location.href = "index.html"; // Navigate to the next page
                    } else {
                        alert("Invalid OTP. Please try again.");
                    }
                };
            } else {
                alert("Failed to send OTP. Please try again later.");
                console.error("SMTPJS Error:", message); // Debugging: Log SMTPJS errors
            }
        })
        .catch((error) => {
            alert("An error occurred while sending the OTP.");
            console.error("Email.send Error:", error); // Debugging: Log any other errors
        });
}
